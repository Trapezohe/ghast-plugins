# Wistia for Ghast

## 简介 / Overview

管理 Wistia 视频库、更新媒体内容并查看视频表现数据。

Manage video libraries, update media and review video performance in Wistia.

## 连接 / Connection

在 Ghast 中连接，通过服务商网页完成 Wistia OAuth 授权；受账号权限与服务配额限制。

Connect in Ghast and complete Wistia OAuth in the provider browser page. Account permissions and service quotas apply.

- MCP: `https://api.wistia.com/mcp/api`
- [官方文档 / Provider documentation](https://docs.wistia.com/docs/mcp-server-guide)

安装后在插件详情连接服务。安装成功不代表账号授权或业务调用成功。

Install the plugin, then connect in its detail page. Installation does not prove account authorization or business task execution.

本包由 Ghast 独立编写，使用服务商公开 MCP，不包含 Codex 私有连接器或账号凭据。

Independently authored for Ghast using public provider MCP services, without Codex private connectors or credentials.

## License / 许可

Ghast-authored manifests and skill text are MIT licensed. Brand names and logos belong to their respective owners. 品牌名称与标识归相应权利人所有。

Brand logo source: https://wistia.com/favicon.ico
