import { wixApiRequest } from "./wix-client.js";

// Data model reference: see INSTRUCTIONS.md

/**
 * Wix Stores V3 Product — key fields for the storefront catalog.
 * Full model: https://dev.wix.com/docs/api-reference/business-solutions/stores/catalog-v3/products-v3/query-products.md
 *
 *   id {string}, name {string}, slug {string}, visible {boolean}, productType "PHYSICAL"|"DIGITAL",
 *   mainCategoryId {string},
 *   media.main.image {object} — { id, url, height, width, altText },
 *   media.itemsInfo.items {array} — gallery: [{ id, altText, image: { id, url, height, width, altText }, mediaType }],
 *   actualPriceRange.minValue.formattedAmount {string} — lowest price with currency symbol,
 *   actualPriceRange.maxValue.formattedAmount {string} — highest price with currency symbol,
 *   compareAtPriceRange.minValue.formattedAmount {string} — strikethrough price (present when on sale),
 *   actualPriceRange/compareAtPriceRange .minValue.amount {string} — the same figures unformatted
 *     ("129.00"). Use these for arithmetic: a percent-off badge can't be computed from "€129.00",
 *   inventory.availabilityStatus {string} — "IN_STOCK"|"OUT_OF_STOCK"|"PARTIALLY_OUT_OF_STOCK",
 *   inventory.preorderStatus {string} — "ENABLED"|"DISABLED". ENABLED + OUT_OF_STOCK is a pre-order,
 *     which is buyable — label it "Pre-order" rather than "Sold out",
 *     NB: inventory carries no stock COUNT. "Limited stock" (from PARTIALLY_OUT_OF_STOCK) is the most
 *     precise scarcity signal a tile can show; "Only 2 left" needs per-variant inventory, i.e. a
 *     getProductBySlug call per product,
 *   ribbon {object} — { id, name } merchant-set badge: "New", "Sale", "Best Seller". This is the
 *     catalogue's own label, so prefer it over anything derived — a "new" badge computed from
 *     createdDate flags every product at once right after seeding,
 *   additionalRibbons {array} — further { id, name } badges,
 *   createdDate / updatedDate {string} — ISO timestamps,
 *   variantSummary.variantCount {number} — how many variants exist, without fetching them,
 *   options {array} — product options e.g. Size, Color:
 *     [{ id, name, optionRenderType "TEXT_CHOICES"|"COLOR_CHOICES"|"SWATCH_CHOICES",
 *        choicesSettings.choices [{ choiceId, key, name, inStock, visible, choiceType, colorCode,
 *                                   linkedMedia }] }],
 *     A COLOR/SWATCH option's choices carry choiceType "ONE_COLOR" and colorCode "#395E55" — render
 *     those as real colour swatches, not text pills. linkedMedia [{ image.url }] holds that colour's
 *     photos, so selecting a swatch can move the gallery to the matching shot. visible false is a
 *     retired choice the merchant no longer sells: filter it out. (TEXT_CHOICES choices are
 *     choiceType "CHOICE_TEXT" with no colorCode.)
 *   modifiers {array} — non-variant customizations (engraving, gift wrap):
 *     [{ id, name, mandatory, modifierRenderType "TEXT_CHOICES"|"FREE_TEXT",
 *        key, choicesSettings.choices, freeTextSettings.key }],
 *   plainDescription {string} — product description as an HTML string (contains <p>, <br>,
 *     <strong>…) despite the "plain" name — NOT plain text. Render with innerHTML /
 *     dangerouslySetInnerHTML; strip tags only for plain-text contexts (meta description, teaser),
 *   variantsInfo.variants {array} — returned only by getProductBySlug:
 *     [{ id, visible, choices [{ optionChoiceIds: { optionId, choiceId } }],
 *        price: { actualPrice, compareAtPrice }, media, inventoryStatus: { inStock } }]
 *     To resolve a buyer's option selections to a variantId: find the variant whose choices
 *     match all selected { optionId, choiceId } pairs, then pass variant.id to addToCart.
 *
 * Category: { id, name, slug, visible, description, image, itemCounter, parentCategory.id }
 *   NB: queryCategories includes the auto-created system category { slug: "all-products" } —
 *   filter it out of a category menu (see INSTRUCTIONS.md). `visible` does not flag it.
 * Full model: https://dev.wix.com/docs/api-reference/business-solutions/stores/catalog-v3/categories
 */

/**
 * Query visible products (one page). Pass nextCursor back as cursor to load the next page.
 * @param {{ limit?: number, cursor?: string }} [options]
 * @returns {Promise<{ products: object[], nextCursor: string|null }>}
 */
export async function queryProducts({ limit = 100, cursor } = {}) {
  const res = await wixApiRequest("/stores/v3/products/query", {
    method: "POST",
    body: {
      fields: ["CURRENCY", "PLAIN_DESCRIPTION", "MEDIA_ITEMS_INFO"],
      query: {
        ...(cursor ? {} : { filter: { visible: true } }),
        cursorPaging: cursor ? { limit, cursor } : { limit },
      },
    },
  });
  return {
    products: res?.products ?? [],
    nextCursor: res?.pagingMetadata?.cursors?.next ?? null,
  };
}

/**
 * Fetch a product by its URL slug. Returns null if not found.
 * Returns the full product including variantsInfo.variants (with per-variant media and choices).
 * @param {string} slug
 * @returns {Promise<object|null>}
 */
export async function getProductBySlug(slug) {
  const res = await wixApiRequest(`/stores/v3/products/slug/${encodeURIComponent(slug)}`, {
    method: "GET",
    query: { fields: ["CURRENCY", "PLAIN_DESCRIPTION", "MEDIA_ITEMS_INFO"] },
  });
  return res?.product ?? null;
}

/**
 * Query visible products belonging to a category (one page).
 * @param {string} categoryId  Category GUID from queryCategories / getCategoryBySlug.
 * @param {{ limit?: number, cursor?: string }} [options]
 * @returns {Promise<{ products: object[], nextCursor: string|null }>}
 */
export async function queryProductsByCategory(categoryId, { limit = 100, cursor } = {}) {
  const res = await wixApiRequest("/stores/v3/products/search", {
    method: "POST",
    body: {
      fields: ["CURRENCY", "PLAIN_DESCRIPTION", "MEDIA_ITEMS_INFO"],
      search: {
        ...(cursor
          ? { cursorPaging: { limit, cursor } }
          : {
              cursorPaging: { limit },
              filter: {
                visible: true,
                "allCategoriesInfo.categories": { $matchItems: [{ id: categoryId }] },
              },
            }),
      },
    },
  });
  return {
    products: res?.products ?? [],
    nextCursor: res?.pagingMetadata?.cursors?.next ?? null,
  };
}

/**
 * Total number of visible products. Used for empty-state logic (0 → prompt user to add products).
 * @returns {Promise<number>}
 */
export async function countProducts() {
  const res = await wixApiRequest("/stores/v3/products/count", {
    method: "POST",
    body: { filter: { visible: true } },
  });
  return res?.count ?? 0;
}

/**
 * Query Wix Stores categories (one page).
 * @param {{ limit?: number, cursor?: string }} [options]
 * @returns {Promise<{ categories: object[], nextCursor: string|null }>}
 */
export async function queryCategories({ limit = 100, cursor } = {}) {
  const res = await wixApiRequest("/categories/v1/categories/query", {
    method: "POST",
    body: {
      treeReference: { appNamespace: "@wix/stores", treeKey: null },
      query: { cursorPaging: cursor ? { limit, cursor } : { limit } },
    },
  });
  return {
    categories: res?.categories ?? [],
    nextCursor: res?.pagingMetadata?.cursors?.next ?? null,
  };
}

/**
 * Get a single category by its URL slug. Returns null if not found.
 * @param {string} slug
 * @returns {Promise<object|null>}
 */
export async function getCategoryBySlug(slug) {
  const res = await wixApiRequest(`/categories/v1/categories/slug/${encodeURIComponent(slug)}`, {
    method: "GET",
    query: { "treeReference.appNamespace": "@wix/stores" },
  });
  return res?.category ?? null;
}
