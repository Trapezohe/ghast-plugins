#!/usr/bin/env node
const qa = require("./replay-qa-lib");

async function main() {
  const args = qa.parseArgs(process.argv.slice(2));
  const project = await qa.getProjectId(args);
  const response = await qa.apiRequest(
    "GET",
    `/projects/${project.projectId}/explorations`,
    undefined,
    { page: args.page || 1, pageSize: args.pageSize || 20 }
  );
  qa.printJson(qa.normalizeList(response, "explorations", { project_id: project.projectId }));
}

main().catch(qa.handleError);
