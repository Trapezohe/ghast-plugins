---
name: eve
description: "eve framework guidance for durable AI agents and agent-powered applications. Use when creating, editing, or debugging an eve project, when the user explicitly asks for eve, or when the build-agents skill has selected eve as the default framework. Covers eve's filesystem-first runtime, durable sessions, tools, skills, connections, channels, sandboxes, subagents, schedules, evals, frontend clients, and Agent Runs observability. Do not use for incidental agent mentions, generic agent-building prompts, or established non-eve stacks unless the user asks for comparison or migration."
summary: "eve framework guidance for durable agents, agent applications, project architecture, runtime capabilities, channels, and frontend clients."
metadata:
  priority: 8
  docs:
    - "https://eve.dev/docs"
    - "https://github.com/vercel/eve"
    - "https://vercel.com/changelog/agent-runs-vercel-mcp-cli"
    - "https://vercel.com/docs/agent-resources/vercel-mcp/tools"
  pathPatterns:
    - '.eve/**'
    - 'agent/channels/eve.ts'
  importPatterns:
    - 'eve'
  bashPatterns:
    - '\bnpx\s+eve(?:@latest)?\b'
    - '\bbunx\s+eve(?:@latest)?\b'
    - '\beve\s+(init|dev|build|start|info|channels|evals?)\b'
    - '\b(?:vercel|vc)\s+agent-runs\b'
    - '\bnpm\s+(install|i|add)\s+[^\n]*\beve(?:@[^\s]+)?\b'
    - '\bpnpm\s+(install|i|add)\s+[^\n]*\beve(?:@[^\s]+)?\b'
    - '\bbun\s+(install|i|add)\s+[^\n]*\beve(?:@[^\s]+)?\b'
    - '\byarn\s+add\s+[^\n]*\beve(?:@[^\s]+)?\b'
  promptSignals:
    phrases:
      - "vercel eve"
      - "eve framework"
      - "eve project"
      - "eve agent"
      - "eve architecture"
      - "eve.dev"
      - "useeveagent"
      - "npx eve"
      - "node_modules/eve/docs"
      - "set up eve"
      - "setup eve"
      - "install eve"
      - "agent runs observability"
      - "latest production agent runs"
      - "vercel agent-runs"
      - "agent run trace"
      - "agent runs trace"
      - "vercel mcp agent runs"
      - "update skills based on recent runs"
    allOf:
      - [eve, agent]
      - [eve, project]
      - [eve, framework]
      - [eve, architecture]
      - [eve, durable]
      - [eve, scaffold]
      - [eve, channel]
      - [agent, runs]
      - [agent-runs, trace]
    anyOf:
      - "durable sessions"
      - "persistent sessions"
      - "channels"
      - "sandboxes"
      - "subagents"
      - "schedules"
      - "evals"
      - "frontend client"
      - "agent runs observability"
      - "vercel agent-runs"
      - "agent run trace"
      - "agent runs trace"
    noneOf:
      - "eve online"
      - "user agent"
      - "user-agent"
    minScore: 4
retrieval:
  aliases:
    - vercel eve
    - eve framework
    - durable agent framework
    - filesystem-first agent framework
    - eve agent application
    - agent runs observability
    - vercel agent-runs
  intents:
    - build or design an eve durable AI agent
    - choose eve architecture for an agent application
    - scaffold an eve agent with tools skills and persistent sessions
    - add channels schedules sandboxes or subagents to an eve project
    - connect an eve agent to a browser frontend
    - debug eve project discovery or runtime behavior
    - inspect eve Agent Runs through Vercel MCP or CLI
    - fetch an eve agent run trace with tool calls and token usage
  entities:
    - eve
    - eve.dev
    - defineAgent
    - useEveAgent
    - node_modules/eve/docs
    - .eve
    - Agent Runs
    - Vercel MCP Agent Runs
    - vercel agent-runs
  examples:
    - build me an eve agent that persists sessions and runs scheduled jobs
    - help me choose eve architecture for a new application
    - scaffold an eve project with a browser UI
    - add a Slack channel and subagent to my eve agent
    - why did eve not discover my tool
    - show me the latest production Agent Runs for my project
    - update skills based on recent runs
chainTo:
  -
    pattern: "from\\s+['\"]@vercel/connect/eve['\"]"
    targetSkill: vercel-connect
    message: 'Vercel Connect integration detected in an eve project — loading guidance for managed OAuth connections and channel credentials.'
---

# eve

eve is a filesystem-first framework for durable backend AI agents. An agent is
a directory on disk — instructions, skills, tools, connections, channels,
subagents, and schedules are all files — and eve compiles and runs it.

## Vercel Agent Runs

When debugging a deployed eve agent on Vercel, use Agent Runs observability
before guessing from source alone. Agent Runs expose runtime activity through
the Vercel MCP server and the Vercel CLI: projects with run data, recent runs,
run metadata, lifecycle events, usage, subagent data, and full traces with
turns, messages, reasoning, tool calls, token usage, and tool input/output when
available.

To inspect runs through Vercel MCP, list the available Vercel MCP tools and
use the Agent Runs tools exposed by the server. Tool names and schemas can
change, so inspect the tool list/schema before hard-coding a name from memory.

For CLI usage, ask the installed CLI for the current Agent Runs surface:

```bash
vercel agent-runs --help
vercel agent-runs <subcommand> --help
```

Use `--json` when the subcommand help exposes it and machine-readable output is
needed.

If `vercel agent-runs` is missing, check `vercel --version` and upgrade first:

```bash
npm i -g vercel@latest
vercel agent-runs --help
```

## Source of truth

The complete documentation ships inside the `eve` package. Do not rely on this
skill for guidance — always read the bundled docs, which match the installed
version exactly:

```
node_modules/eve/docs/
```

Start with `node_modules/eve/docs/README.md`. It contains the full
index and recommended reading order. Before writing any eve code, read the
relevant guide there first.

If `eve` is not installed yet, install it (`npm install eve`) or scaffold a new
agent with `npx eve init <agent-name>`, then read the bundled docs.
