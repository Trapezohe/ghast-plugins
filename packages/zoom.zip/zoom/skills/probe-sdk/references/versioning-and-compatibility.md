# Probe SDK Versioning and Compatibility

## Upgrade Strategy

Use the repository-standard workflow:
- [../../general/references/sdk-upgrade-workflow.md](../../general/references/sdk-upgrade-workflow.md)

Current verified npm release: `@zoom/probesdk@1.0.4` (2026-07-10).

Release `1.0.4` also fixes inconsistent network-bandwidth units. Re-baseline thresholds and
telemetry dashboards if they were calibrated against an earlier package.

## Compatibility Risks

- Renderer option naming drift (`type` vs `rendererType`) across docs/examples.
- Report object field naming drift (`basicInfo` vs `basicInfoEntries`, `supportedFeatures` vs `featureEntries`).
- Browser support table age vs current browser versions.
- Runtime JS/WASM URL override mismatches.
- Chrome-only camera-dump support and browser API availability.
- Screen-share diagnostics requiring secure context and explicit picker interaction.

## Safe Upgrade Checklist

- Pin and record current/target `@zoom/probesdk` version.
- Compare get-started docs, API reference, and sample repo behavior.
- Validate all renderer targets in your browser matrix.
- Validate both full diagnostic completion and early stop path.
- Validate report schema adapter and downstream consumers.
- Pin JS/WASM assets to the same Probe SDK release and prevent mixed-version loading.
- Add cache-busting strategy for JS/WASM updates (asset fingerprinting or versioned URLs).
- Confirm CDN/browser cache invalidation behavior before production rollout.
