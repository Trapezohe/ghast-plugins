# PlanetScale for Ghast

## 简介 / Overview

查询 PlanetScale 数据库、分支、表结构与查询性能。

Inspect databases, branches, schemas and query performance with PlanetScale.

## 连接 / Connection

在 Ghast 中连接，通过服务商网页完成 PlanetScale OAuth 授权；受账号权限与服务配额限制。

Connect in Ghast and complete PlanetScale OAuth in the provider browser page. Account permissions and service quotas apply.

- MCP: `https://mcp.pscale.dev/mcp/planetscale`
- [官方文档 / Provider documentation](https://planetscale.com/docs/mcp-server)

安装后在插件详情连接服务。安装成功不代表账号授权或业务调用成功。

Install the plugin, then connect in its detail page. Installation does not prove account authorization or business task execution.

本包由 Ghast 独立编写，使用服务商公开 MCP，不包含 Codex 私有连接器或账号凭据。

Independently authored for Ghast using public provider MCP services, without Codex private connectors or credentials.

## License / 许可

Ghast-authored manifests and skill text are MIT licensed. Brand names and logos belong to their respective owners. 品牌名称与标识归相应权利人所有。

Brand logo source: https://cdn.simpleicons.org/planetscale
