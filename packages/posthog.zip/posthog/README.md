# posthog

Analyze and manage PostHog product analytics, SQL, feature flags, experiments,
dashboards, errors, replays, surveys, logs, AI observability, data pipelines,
and workflows through PostHog's official hosted MCP server.

## Official hosted MCP adapter

This package contains only Ghast-authored MCP configuration, safety
instructions, documentation, and catalog metadata. It does not copy or
redistribute PostHog's hosted service, the private Codex app connector, the
PostHog MCP server source, PostHog data, marketplace artwork, or the current
AI plugin's mixed-source static skill bundle.

The adapter is pinned to PostHog's official MCP overview at SHA-256
`dbbdc9b00c575addbd8bec5a54de69ee0ac70e2b3e44ec3558bc42f44ca48660`, tool reference at `eacebb2b96270f4065a0346dad04465143c721a3c724e11cdf4027afd14aa698`, and
FAQ at `68a72a80b5726980e3b2c754079c76de0b5c20ecce83a01fb5ef33879cc67858`. It also verifies the official PostHog monorepo
at `bbc6f4bf597f133e3ca435ed300835036a23a4a7`: the root MIT-style license, `@posthog/mcp`
package metadata, service README, complete tool-definition schema, and
generated CLI command reference.

The OAuth protected-resource metadata is pinned at canonical JSON SHA-256
`9b7b445acd711f55e50db0deb96f341769cb3a073f7e466cc5efc38da3341283` and the authorization-server metadata at
`3b1f34cd44dadf05dd7cf4e9b24519410bc15ffa9353929b865f0f28451eebb7`.

## Ghast compatibility

- Ghast connects directly to `https://mcp.posthog.com/mcp` over Streamable HTTP, sends
  PostHog's documented `plugin` consumer marker, and pins the server's
  token-efficient CLI mode. OAuth uses authorization-code and refresh-token
  grants, public clients, and PKCE S256.
- The source schema and official tool page currently contain 844 matching
  unique tool names across analytics, flags, experiments, errors, replays,
  surveys, dashboards, SQL, AI observability, logs, pipelines, support,
  workflows, and newer PostHog products. The page's 58 category badges sum to
  837, so Ghast records that official documentation inconsistency rather than
  silently choosing one count.
- The pinned source marks 449 definitions read-only and 109 destructive.
  PostHog removed three read-only legacy session-recording summary tools on
  August 13, 2026: `session-recording-summaries-list`,
  `session-recording-summarize`, and `session-recording-summary-get`. No
  replacement tool names were added in that update. PostHog also supports a
  read-only session mode, organization and project pinning, feature-category
  filtering, and exact tool allowlists.
- This operational surface is broader than the OpenAI marketplace snapshot's
  PostHog app description and preserves its read/write product workflows. The
  current server also exposes MCP resources and prompts.
- PostHog's separate official AI plugin currently contains 137 synchronized
  static skills but no repository-level license file. Its workflow imports
  one source stream from `PostHog/context-mill`, which also publishes no
  license file. Ghast therefore does not redistribute those files or claim
  byte-for-byte parity with that static guidance layer.
- On August 13, 2026, the live endpoint returned the official OAuth challenge
  without credentials, and the advertised registration endpoint accepted a
  disposable loopback public client. Authenticated tool listing and project
  operations were not run because they require a PostHog account and data.
Brand logo source: https://avatars.githubusercontent.com/u/60330232?v=4. The logo belongs to PostHog. 品牌标识归对应服务商所有。

The MIT license in this package applies only to the Ghast-authored adapter.
PostHog accounts, plans, hosted service behavior, analytics data, permissions,
AI spend, trademarks, privacy policy, and terms remain controlled by PostHog.
